import setuptools

setuptools.setup(
    name="bartviewer",
    version="0.0.1",
    description="Jupyter port of Matplotlib-based BART viewer"
)