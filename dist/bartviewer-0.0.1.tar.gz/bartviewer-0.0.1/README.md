# bart-view-nb
jupyter notebook widget to view multi-dimensional complex float (`.cfl`) data in-line.
