import setuptools

setuptools.setup(
    name="bart-view-widget-mrirecon",
    version="0.0.1",
    description="Jupyter port of Matplotlib-based BART viewer"
)